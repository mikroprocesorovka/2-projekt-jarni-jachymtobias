#include "stm8s.h"
#include "milis.h"
#include "keypad.h"
#include "stm8s_adc2.h"
#include "spse_stm8.h"
#include "stdio.h"

// 			PWM - LED
#define CHANGE_POSITION_TIME 50 // defaultn� nastaven� zm�ny [50 us]
#define DEFAULT_PULSE 10
#define MAX_PULSE 500
#define STEP	20
//			funkce na ovl�d�n� kl�vesnice
void process_keypad(void);
//   		definov�n� funkc� (nastaven�)
void keypad_init(void);
void init_pwm(void);
void ADC_init(void);
// 			UART funkce
void uart_putchar(char data); 	// po�le jeden znak na UART
void uart_puts(char* retezec); 	// po�le cel� �et�zec a UART
// 			funkce obsluhuj�c� blik�n� LEdky
void process_pwm_change(void);
// 			text zobrazuj�c� se v PC p�es UART
char text[24];
//  		prom�nn� pro po�et bliknut� LEdkou a zm�ny jasu
uint16_t PWM_time = CHANGE_POSITION_TIME;
uint8_t LED_timer = 0;
// 			prom�nn� s hodnotou z ADC p�evodn�ku
uint16_t value;


void main(void){
CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1); // 16MHz z intern�ho RC oscil�toru
UART1_Init(115200,UART1_WORDLENGTH_8D,UART1_STOPBITS_1,UART1_PARITY_NO,UART1_SYNCMODE_CLOCK_DISABLE,UART1_MODE_TX_ENABLE);
UART1_Cmd(ENABLE);


init_milis(); 
keypad_init();
init_pwm();
ADC_init();

  while (1){
		process_keypad(); 								// sn�mej stisknut� kl�vesy na kl�vesnici
		process_pwm_change();							// m�� jas LEdky
		value = ADC_get(ADC2_CHANNEL_0); 	// aktualizuj hodnotu z ADC p�evodn�ku
  }
}

// ### inicializace
void init_pwm(void){ 	// nastaven� pin� PWM - LEDka
	GPIO_Init(GPIOD, GPIO_PIN_4, GPIO_MODE_OUT_PP_LOW_FAST);

	TIM2_TimeBaseInit(TIM2_PRESCALER_16, MAX_PULSE - 1);

	TIM2_OC1Init( 					// inicializujeme kan�l 1 (TM2_CH1)
		TIM2_OCMODE_PWM1, 				// re�im PWM1
		TIM2_OUTPUTSTATE_ENABLE,	// V�stup povolen (TIMer ovl�d� pin)
		DEFAULT_PULSE,						// v�choz� hodnota ���ky pulzu je 1.5ms
		TIM2_OCPOLARITY_HIGH			// Z�t� rozsv�c�me hodnotou HIGH 
	);
	
	TIM2_OC1PreloadConfig(ENABLE);
	TIM2_Cmd(ENABLE);
}

void ADC_init(void){ 		// nastaven� ADC p�evodn�ku
	// na pinech/vstupech ADC_IN2 (PB2) a ADC_IN3 (PB3) vypneme vstupn� buffer
	ADC2_SchmittTriggerConfig(ADC2_SCHMITTTRIG_CHANNEL0,DISABLE);//PB0
	ADC2_SchmittTriggerConfig(ADC2_SCHMITTTRIG_CHANNEL1,DISABLE);//PB1
	// nastav�me clock pro ADC (16MHz / 4 = 4MHz)
	ADC2_PrescalerConfig(ADC2_PRESSEL_FCPU_D4);
	// vol�me zarovn�n� v�sledku (typicky vpravo, jen vyjme�n� je v�hodn� vlevo)
	ADC2_AlignConfig(ADC2_ALIGN_RIGHT);
	// nasatv�me multiplexer na n�kter� ze vstupn�ch kan�l�
	ADC2_Select_Channel(ADC2_CHANNEL_0);//PB0
	ADC2_Select_Channel(ADC2_CHANNEL_1);//PB1
	// rozb�hneme AD p�evodn�k
	ADC2_Cmd(ENABLE);
	// po�k�me ne� se AD p�evodn�k rozb�hne (~7us)
	ADC2_Startup_Wait();
}

// ### Kl�vesnice
void process_keypad(void){
	static uint8_t minule_stisknuto=0xFF;											// posledn� stav kl�vesnice (zde "volno")
	static uint16_t last_time=0; 															// posledn� �as kontroly stisku
	uint8_t stisknuto;																				// aktu�ln� stisknut�kl�vesnice
	uint32_t temp;

	if(milis()-last_time > 20){ // ka�d�ch 20 ms ...
		last_time = milis();
		stisknuto = keypad_scan(); // ... skenujeme kl�vesnici
		
		if(minule_stisknuto == 0xFF && stisknuto != 0xFF){ // uvoln�no a pak stisknuto - pouze stisk, nikokli dr�en�
			minule_stisknuto = stisknuto;
			
			if (stisknuto > 0)
			{
				LED_timer += stisknuto;
				
				sprintf(text,"%Count: %3u. \n\r",stisknuto); 	// zobrazen� stisknut� kl�vesy na UART
				uart_puts(text);
				
				//temp = 10 + (((uint32_t)value * 30 + 512) / 1024) % 40; 	// 10 - 40 ms time change for LED 	(p�esn�j��)
				temp = 10 + (value / 100) * 2; 	// 10 - 30 ms time change for LED 
				PWM_time = temp; 	
			}
		}
		if(stisknuto == 0xFF){minule_stisknuto=0xFF;}
	}
}

// ### Pulzov�n� LEdky
// neblokuj�c�m zp�sobem obsluhujeme zm�nu st��dy
void process_pwm_change(void){
	static uint16_t pulse = DEFAULT_PULSE; // v�choz� ���ka pulzu
	static uint16_t last_time = 0;  
	static int8_t zmena = STEP;	//bude m�t + a - a o tuhle hodnotu bude rozsv�cet a zhas�nat LEDku

  if(milis() - last_time >= PWM_time){ //rychlost zm�ny
		last_time = milis();
		if (LED_timer > 0)
		{
			pulse = pulse + zmena; 		// zm�na pulzu u LEdky (jas)
			
			
			if(pulse > MAX_PULSE - STEP || pulse < STEP){
				if (pulse < STEP) 		// prom�nn� blikla - sni� po�et bliknut� o 1
				{
					LED_timer --;
				}
				zmena = zmena*(-1);																		// pokud jsme na konci rozsahu, za�neme od za��tku v us
			} 	
			
			TIM2_SetCompare1(pulse); 																// zap�eme ���ku pulzu do timeru
		}
  }
}

// ### UART info odesl�n�
// po�le jeden znak na UART
void uart_putchar(char data){
 while(UART1_GetFlagStatus(UART1_FLAG_TXE) == RESET);
 UART1_SendData8(data);
}

// po�le UARTem �et�zec 
void uart_puts(char* retezec){ 
 while(*retezec){
  uart_putchar(*retezec);
  retezec++;
 }
}


// pod t�mto koment��em nic nem��te 
#ifdef USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param file: pointer to the source file name
  * @param line: assert_param error line source number
  * @retval : None
  */
void assert_failed(u8* file, u32 line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif
